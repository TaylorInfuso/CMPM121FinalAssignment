﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
	
	public float[] surface;
	public Rigidbody rb;
	private Vector3 pastPos;
	private float waitToFall;
	
    // Start is called before the first frame update
    void Start()
    {
		surface = new float [4];
        for (int i = 0; i < 4; i++){
			surface[i] = 0;
		}
		rb.AddForce(new Vector3(0,-2000, 0));
		pastPos = transform.position;
		waitToFall = 0;
    }

    // Update is called once per frame
    void Update()
    {
		print("side0: " + surface[0] + ", side1:" + surface[1] + ", side2: " + surface[2] + ", side3: " + surface[3]);
		
		var boxC = this.GetComponent<BoxCollider>();
		//print(boxC.size[0]);
		
		Vector3 speed = rb.velocity;
		//print(speed[0] + ", " + speed[1]);
		if((speed[0] < -4 || speed[0] > 4) || (speed[1] < -4 || speed[1] > 4)){
			boxC.size = new Vector3(1.9f, 1.9f, 1.9f);
		}
		else if(boxC.size[0] != 2 && boxC.size[1] != 2 && boxC.size[2] != 2 && 
			(surface[0] != 0 || surface[1] != 0 || surface[2] != 0 || surface[3] != 0)){
			waitToSize();
			boxC.size = new Vector3(2, 2, 2);
		}
			
		
		//print(speed[0] + ", " + speed[1]);
		
		
		if((surface[0] == 1 || surface[2] == 1))
			rb.constraints =  RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotation;
		else if((surface[1] == 1 || surface[3] == 1))
			rb.constraints =  RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotation;
		
		
		//this.transform.Rotate(0,0,1);
		Control();
    }		
	
	public IEnumerator waitToSize(){
		yield return new WaitForSeconds(0.5f);
		yield return null;
	}
	
	public IEnumerator freeFall(){
		yield return new WaitForSeconds(0.1f);
		Vector3 currentPos = transform.position;		
		if(waitToFall >= 2){
			if((pastPos[0] + 1 < currentPos[0] || pastPos[0] - 1 > currentPos[0]) && surface[0] == 0 && surface[1] == 0 && surface[2] == 0 && surface[3] == 0){
				rb.AddForce(new Vector3(0, -2000, 0));
				rb.constraints =  RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotation;
				print("first fall");
			}
			else if ((pastPos[1] - 1 > currentPos[1] || pastPos[1] + 1 < currentPos[1]) && surface[0] == 0 && surface[1] == 0 && surface[2] == 0 && surface[3] == 0){
				rb.AddForce(new Vector3(0, -2000, 0));
				rb.constraints =  RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotation;
				print("second fall");
			print("well at least this runs");
			}
		}
		yield return null;
	}
	
	public IEnumerator turnOnFreeFall(){
		yield return new WaitForSeconds(0.5f);
		yield return null;
	}


	public void OnCollisionExit(Collision collider){	

		if (collider.gameObject.CompareTag("block")){
			Vector3 colRot = collider.transform.localEulerAngles;
			if(colRot[2] == 0)
				surface[0] = 0;
			else if(colRot[2] == 90)
				surface[1] = 0;
			else if(colRot[2] == 180)
				surface[2] = 0;
			else if(colRot[2] == 270)
				surface[3] = 0;
			StartCoroutine("freeFall", 100);
			}
		else if (collider.gameObject.CompareTag("platform")){
			for(int i = 0; i < 4; i++)
				surface[i] = 0;
			StartCoroutine("freeFall", 100);
			}
		}
	public void OnCollisionStay(Collision collider){
		waitToFall += 0.5f;
		if (collider.gameObject.CompareTag("block")){
			Vector3 colRot = collider.transform.localEulerAngles;
			if(colRot[2] == 0)
				surface[0] = 1;
			else if(colRot[2] == 90)
				surface[1] = 1;
			else if(colRot[2] == 180)
				surface[2] = 1;
			else if(colRot[2] == 270)
				surface[3] = 1;			
		}
		else if (collider.gameObject.CompareTag("platform")){
			Vector3 currentPos = transform.position;
			Vector3 colPos = collider.transform.position;
			if((currentPos[0] - 1.9f <= colPos[0] && currentPos[0] + 1.9f >= colPos[0]) || 
				(currentPos[1] - 1.9f <= colPos[1] && currentPos[1] + 1.9f >= colPos[1])){
			//print(currentPos[0] + " vs " + colPos[0] + " and " + currentPos[1] + " vs " + colPos[1]);
			if(pastPos[0] + 1 < currentPos[0])
				surface[1] = 1; 
			else if (pastPos[0] - 1 > currentPos[0])
				surface[3] = 1;
			else if (pastPos[1] + 1 < currentPos[1])
				surface[2] = 1;
			else if (pastPos[1] - 1 > currentPos[1])
				surface[0] = 1;
			}
			else{
				for(int i = 0; i < 4; i++)
					surface[i] = 0;
				print("FALL");
				//collider.gameObject.GetComponent<BoxCollider>().enabled = false;
				rb.AddForce(new Vector3(0, -2000, 0));
				waitToFall = 2;
				//reEnablePlat(collider.gameObject);
				var boxC = this.GetComponent<BoxCollider>();
				boxC.size = new Vector3(1.9f, 1.9f, 1.9f);
				rb.constraints =  RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotation;
			}
		}
	}
		public IEnumerator reEnablePlat(GameObject col){
			yield return new WaitForSeconds(0.5f);	
			col.gameObject.GetComponent<BoxCollider>().enabled = true;
			yield return null;
		}
	
	
		public void Control(){
			Vector3 v3 = transform.position;
			//print("v0: " + v3[0] + ", v1:" + v3[1] + ", v2: " + v3[2]);
		
        if(Input.GetKeyDown("a")){
			pastPos = transform.position;
			if(surface[0] == 1 && surface[1] == 1){
				this.transform.Rotate(0,0,-90);
				v3[1] +=2;
				Normalize(v3);
			}
			else if(surface[1] == 1 && surface[2] == 1){
				this.transform.Rotate(0,0,90);
				v3[1] -=2;
				Normalize(v3);
			}
			else if(surface[2] == 1 && surface[3] == 1){
				this.transform.Rotate(0,0,90);
				v3[0] +=2;
				Normalize(v3);
			}
			else if(surface[0] == 1){
				this.transform.Rotate(0,0,-90);
				v3[0] +=2;
				Normalize(v3);
			}
			else if(surface[1] == 1){
				this.transform.Rotate(0,0,-90);
				v3[1] +=2;
				Normalize(v3);
			}
			else if(surface[2] == 1){
				this.transform.Rotate(0,0,90);
				v3[0] +=2;
				Normalize(v3);
			}
			else if(surface[3] == 1){
				this.transform.Rotate(0,0,-90);
				v3[1] -=2;
				Normalize(v3);
			}
		}
		if(Input.GetKeyDown("d")){
			pastPos = transform.position;
			if(surface[0] == 1 && surface[3] == 1){
				this.transform.Rotate(0,0,90);
				v3[1] +=2;
				Normalize(v3);
			}
			else if(surface[1] == 1 && surface[2] == 1){
				this.transform.Rotate(0,0,-90);
				v3[0] -=2;
				Normalize(v3);
			}
			else if(surface[2] == 1 && surface[3] == 1){
				this.transform.Rotate(0,0,-90);
				v3[1] -=2;
				Normalize(v3);
			}			
			else if(surface[0] == 1){
				this.transform.Rotate(0,0,90);
				v3[0] -=2;
				Normalize(v3);
			}
			else if(surface[1] == 1){
				this.transform.Rotate(0,0,90);
				v3[1] -=2;
				Normalize(v3);
			}
			else if(surface[2] == 1){
				this.transform.Rotate(0,0,-90);
				v3[0] -=2;
				Normalize(v3);
			}
			else if(surface[3] == 1){
				this.transform.Rotate(0,0,90);
				v3[1] +=2;
				Normalize(v3);
			}
		}

		if (Input.GetKeyDown("space") && waitToFall > 1){
			pastPos = transform.position;
			waitToFall = 0;
			if(surface[0] == 1)
				rb.AddForce(new Vector3(0, 2000, 0));
			else if(surface[2] == 1)
				rb.AddForce(new Vector3(0, -2000, 0));
			else if(surface[1] == 1)
				rb.AddForce(new Vector3(-2000, 0, 0));
			else if(surface[3] == 1)
				rb.AddForce(new Vector3(2000, 0, 0));
		}
		
		if(waitToFall > 1)
			Normalize(v3);
		}
		
		public void Normalize(Vector3 v3){
			if(surface[0] == 1 || surface[1] == 1 || surface[2] == 1 || surface[3] == 1){
				v3[0] = Mathf.Round(v3[0]);
				v3[1] = Mathf.Round(v3[1]);
				v3[2] = Mathf.Round(v3[2]);
			}
			this.transform.position = v3;
			//rb.velocity = new Vector3 (0,0,0);
		}
	}
